#Mencetak judul dari program
print('Biodata Anak Pacil 2021')

#Mengambil input dari user dan menyimpannya ke dalam variabel-variabel
nama = input('Nama: ')
alamat = input('Alamat: ')
tanggal_lahir = input('Tanggal Lahir: ')
hobi = input('Hobi: ')
makanan_favorit = input('Makanan Favorit: ')

#Mencetak isi dari variabel-variabel
print()
print('Biodataku:')
print(nama)
print(alamat)
print(tanggal_lahir)
print(hobi)
print(makanan_favorit)